import React from "react";

const Experience = () => {
    return <div>Experience</div>;
};

export default Experience;
